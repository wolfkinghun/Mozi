import React from 'react'


export const SearchPage = () => {
  return (
    <div>
      SearchPage
    </div>
  )
}

