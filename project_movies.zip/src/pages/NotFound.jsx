import React from 'react'

export const NotFound = () => {
  return (
    <div>
      NotFound
    </div>
  )
}

